#!C:\Users\Megha Home\AppData\Local\Programs\Python\Python310\python
import os
# Import modules for CGI handling
import cgi, cgitb
import urllib.request
import pandas as pd
#from HaarWavelet import *
from DBInsertion import *
import Sentiment.preprocess
from Sentiment.stats import * 
from nltk.stem.porter import PorterStemmer
#from HOG import *


# enable debugging
cgitb.enable()
# print content type
print("Content-type:text/html\r\n\r\n")
print("path="+os.getcwd()) 
form = cgi.FieldStorage() 
path=form.getvalue("path") 
id=form.getvalue("id") 
UPLOAD_DIR=os.getcwd()+"\\Sentiment\\ReviewsDataSet\\" 
 
use_stemmer = False
csv_file_name = UPLOAD_DIR+path
csv_file_name1 = UPLOAD_DIR+"NANRemoved_"+path
processed_file_name = path[:-4] + '-processed.csv'
if use_stemmer:
    porter_stemmer = PorterStemmer()
    processed_file_name = path[:-4] + '-processed-stemmed.csv'
print("before preprocessing")

df = pd.read_csv(csv_file_name)
df.dropna(how='all').dropna(how='all', axis=1)
df = df[df.filter(regex='^(?!Unnamed)').columns]

df.to_csv(csv_file_name1, index=False,header=None)
Sentiment.preprocess.preprocess_csv(csv_file_name1, UPLOAD_DIR+processed_file_name, test_file=False)
start(UPLOAD_DIR+processed_file_name)
print("<html>")
print("<head>")
print("<meta http-equiv='refresh' content='0;url=http://localhost:8080/datasetPreprocessingPython?sts=success&id="+id+"'/>")
print("</head>")
print("</html>")