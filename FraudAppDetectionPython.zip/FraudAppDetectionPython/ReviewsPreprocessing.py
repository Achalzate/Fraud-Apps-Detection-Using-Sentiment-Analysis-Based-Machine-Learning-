#!C:\Users\Megha Home\AppData\Local\Programs\Python\Python310\python
import os
# Import modules for CGI handling
import cgi, cgitb
import urllib.request
#from HaarWavelet import *
from DBInsertion import *
import Sentiment.preprocess
from Sentiment.stats import * 
from nltk.stem.porter import PorterStemmer
#from HOG import *


# enable debugging
cgitb.enable()
# print content type
print("Content-type:text/html\r\n\r\n")
print("path="+os.getcwd()) 
form = cgi.FieldStorage() 
path=form.getvalue("path") 
id=form.getvalue("id") 
UPLOAD_DIR=os.getcwd()+"\\Sentiment\\Reviews\\" 
 
use_stemmer = False
csv_file_name = UPLOAD_DIR+path
processed_file_name = path[:-4] + '-processed.csv'
if use_stemmer:
    porter_stemmer = PorterStemmer()
    processed_file_name = path[:-4] + '-processed-stemmed.csv'
print("before preprocessing")
Sentiment.preprocess.preprocess_csv(csv_file_name, UPLOAD_DIR+processed_file_name, test_file=True)
#start(UPLOAD_DIR+processed_file_name)
print("<html>")
print("<head>")
print("<meta http-equiv='refresh' content='0;url=http://localhost:8080/ReviewsPreprocessingPython?sts=success&id="+id+"'/>")
print("</head>")
print("</html>")