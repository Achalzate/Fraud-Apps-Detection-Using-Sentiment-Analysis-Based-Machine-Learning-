#!C:\Users\Megha Home\AppData\Local\Programs\Python\Python310\python
# Import Basic OS functions
import os
# Import modules for CGI handling
import cgi, cgitb
import urllib.request
#from HaarWavelet import *
from DBInsertion import *
from Tweets import *
#from HOG import *


# enable debugging
cgitb.enable()
# print content type
print("Content-type:text/html\r\n\r\n")
print("path="+os.getcwd()) 
#print() 
#form=cgi.FieldStorage()

fid="2.jpg"
# HTML INPUT FORM
HTML = """
<html>
<head>
<title></title>
</head>
<body>

  <h1>Upload File</h1>
  <form action="http://localhost:64203/Default.aspx" method="POST">
    File: <input name="file" type="file">
    <input name="submit" type="submit">
</form>

{% if filedata %}

<blockquote>

{{filedata}}

</blockquote>

{% endif %}  

</body>
</html>
"""
filename=""
ext=""
uploaded_file_path=""
inFileData = None
form = cgi.FieldStorage() 
docid=getMaxIdInput()
UPLOAD_DIR=os.getcwd()+"\\Sentiment\\Tweets\\" 
#print("value="+form.getvalue("uid"))
# IF A FILE WAS UPLOADED (name=file) we can find it here.
#fid=form.getvalue("fid")
#print(form) 
headers = {'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:23.0) Gecko/20100101 Firefox/23.0'}
#print(jinja2.Environment().from_string(HTML).render(filedata=inFileData)) 
#w2d("E:\\python\\1.jpg",'haar','111')
#print(form.getvalue("fid"))
title=form.getvalue("title") 
dt=form.getvalue("dt")
tm=form.getvalue("tm") 
dataset=form.getvalue("dataset") 
userid=form.getvalue("userid") 
filename=str(docid)+".csv"
#print(docid) 
getTweets(UPLOAD_DIR+str(docid)+".csv",title)
#encrypt(getKey(seckey), filename)
insertInput(title,filename,docid,dt,tm,dataset,userid)
 
print("<html>")
print("<head>")
print("<meta http-equiv='refresh' content='0;url=http://localhost:8081/datasetInsrtPython1?sts=success'/>")
print("</head>")
print("</html>")
 