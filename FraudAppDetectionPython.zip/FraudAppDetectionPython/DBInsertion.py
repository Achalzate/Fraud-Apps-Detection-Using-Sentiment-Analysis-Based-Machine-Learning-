from DBConnect import *
import os
import shutil
def insertDoc1(title="NA",docPath="NA",dsId=0,dt="NA",tm="NA" ) : 
    conn = connect()    
    cursor = conn.cursor()
    args = [docPath,title,dt,tm,dsId ]
    args1=cursor.callproc('insertDataSet', args)
    print("Return value:", args1)
    #for result in cursor.stored_results():
     #       print(result.fetchall())
    cnt=cursor.rowcount 
    conn.commit()
def insertInput(title="NA",docPath="NA",dsId=0,dt="NA",tm="NA",dataset=0,uid="NA") : 
    conn = connect()    
    cursor = conn.cursor()
    args = [uid,docPath,title,dt,tm,dsId,dataset]
    args1=cursor.callproc('insertInput', args)
    print("Return value:", args1)
    #for result in cursor.stored_results():
     #       print(result.fetchall())
    cnt=cursor.rowcount 
    conn.commit()
def deleteReviews() : 
    conn = connect()    
    cursor = conn.cursor()
    
    args1=cursor.callproc('deleteTweets')
    print("Return value:", args1)
    #for result in cursor.stored_results():
     #       print(result.fetchall())
    cnt=cursor.rowcount 
    conn.commit()
def insertReviews(txt="NA") : 
    conn = connect()    
    cursor = conn.cursor()
    args = [txt]
    args1=cursor.callproc('insertReviews', args)
    print("Return value:", args1)
    #for result in cursor.stored_results():
     #       print(result.fetchall())
    cnt=cursor.rowcount 
    conn.commit()
def insertReviewsResult(total,pos,neg,id,dsid,neutral,fraudwords,result) : 
    conn = connect()    
    cursor = conn.cursor()
    args = [total,pos,neg,id,dsid,neutral,fraudwords,result]
    args1=cursor.callproc('insertResult', args)
    print("Return value:", args1)
    #for result in cursor.stored_results():
     #       print(result.fetchall())
    cnt=cursor.rowcount 
    conn.commit()
def updateReviews(txt="NA",id=0) : 
    conn = connect()    
    cursor = conn.cursor()
    args = [txt,id]
    args1=cursor.callproc('updateReview', args)
    print("Return value:", args1)
    #for result in cursor.stored_results():
     #       print(result.fetchall())
    cnt=cursor.rowcount 
    conn.commit()


    #args = [userid,title,docPath,docDesc,dt,tm,key]
    #args1=cursor.callproc('insertDoc', args)
    #print("Return value:", args1)
    #for result in cursor.stored_results():
    #        print(result.fetchall())
    #cnt=cursor.rowcount
    #conn.commit()
    #return cnt
def getMaxIdTweet():
    conn = connect()
    #integrated security 
    cursor = conn.cursor() 
    cursor.execute('select (ifnull(max(id),1000)+1) as mxid from tweets;')
    mxid=0
    for row in cursor: 
        mxid=row[0]
        print(int(mxid)+1)
    return mxid 
def getMaxIdDoc1():
    conn = connect()
    #integrated security 
    cursor = conn.cursor() 
    cursor.execute('select (ifnull(max(dsId),1000)+1) as mxid from dataset;')
    mxid=0
    for row in cursor: 
        mxid=row[0]
        print(int(mxid)+1)
    return mxid
def getMaxIdInput():
    conn = connect()
    #integrated security 
    cursor = conn.cursor() 
    cursor.execute('select (ifnull(max(dsId),1000)+1) as mxid from inputCSV;')
    mxid=0
    for row in cursor: 
        mxid=row[0]
        print(int(mxid)+1)
    return mxid
def updateCluster(id=0,cluster=0) : 
    conn = connect()    
    cursor = conn.cursor()
    args = [id,cluster]
    args1=cursor.callproc('updateCluster', args)
    print("Return value:", args1)
    #for result in cursor.stored_results():
     #       print(result.fetchall())
    cnt=cursor.rowcount 
    conn.commit()
def exportToDat(inputid) : 
    conn = connect()
    #integrated security 
    cursor = conn.cursor() 
    cursor.execute("select inputid,postive,negative,neutral,fraudwords from reviews where inputid="+inputid+" order by id desc limit 1")
    print("select inputid,postive,negative,neutral,fraudwords from reviews where inputid="+inputid)
    mxid=""
    record = cursor.fetchall()
    final_result = [list(i) for i in record]
    print(final_result)
    lst=[]
    """
    with open('outfile.csv','w') as f:
        writer = csv.writer(f)
        for row in final_result:
            writer.writerow(row)
    """
    UPLOAD_DIR=os.getcwd()+"\\Clustering_DataSet\\" 
    try:     
        os.remove(UPLOAD_DIR+"outfile.dat")  
    except Exception:
        print("directory exist")
    shutil.copy(UPLOAD_DIR+"outfile1.dat", UPLOAD_DIR+"outfile.dat")
    with open(UPLOAD_DIR+'outfile.dat','a') as f:
        for row in final_result:  
            f.write("\n"+str(row[0])+" ") 
            f.write(str(float(row[1]))+" ")
            f.write(str(float(row[2]))+" ")
            f.write(str(float(row[3]))+" ")
            f.write(str(float(row[4])))
             
def countOccurrences(str, word):
     
    # split the string by spaces in a
    a = str.split(" ")
 
    # search for pattern in a
    count = 0
    for i in range(0, len(a)):
         
        # if match found increase count 
        if (word == a[i]):
           count = count + 1
            
    return count 
def countFraudWords(str):
    conn = connect()
    #integrated security 
    cursor = conn.cursor() 
    cursor.execute('select distinct(word) from fraudwords')
    word="NA"
    count=0
    for row in cursor: 
        word=row[0] 
        word=word.strip()
        count=count+countOccurrences(str,word)
    return count
  