from kmeans import KMeans
import os
UPLOAD_DIR=os.getcwd()+"\\Clustering_DataSet\\" 
ikmeans = KMeans(UPLOAD_DIR+"\\outfile.dat", 2)
ikmeans.process()
ikmeans.flush(UPLOAD_DIR+"\\k-means-out.dat")