from wordcloud import WordCloud, STOPWORDS
#import matplotlib.pyplot as plt
import pandas as pd
import csv 
import cv2
# Reads 'Youtube04-Eminem.csv' file
#df = pd.read_csv("Sentiment/Tweets/1006.csv", encoding ="latin-1")
 
def wordcloudImg(fileNm="NA"):
    comment_words = ''
    stop_words = ["b", "user_mention","url"] + list(STOPWORDS)
    stopwords = set(STOPWORDS)
    with open(fileNm) as csv_file:
            csv_reader = csv.reader(csv_file, delimiter=',')
            line_count = 0
            for row in csv_reader: 
                val = str(row[1])
                tokens = val.split()
                
                # Converts each token into lowercase
                for i in range(len(tokens)):
                    tokens[i] = tokens[i].lower()
        
                comment_words += " ".join(tokens)+" "
    wordcloud = WordCloud(width = 800, height = 800,
                    background_color ='white',
                    stopwords = stop_words,
                    min_font_size = 10).generate(comment_words)
    # iterate through the csv file
    wordcloud.to_file('wordcloud.jpg')
    from nltk import FreqDist
    #text = "Learn and practice and learn to practice"
    words = comment_words.split()
    fdist1 = FreqDist(words)
    print(fdist1)
    print(fdist1.most_common())
"""
for val in df.CONTENT:
     
    # typecaste each val to string
    val = str(val)
 
    # split the value
    tokens = val.split()
     
    # Converts each token into lowercase
    for i in range(len(tokens)):
        tokens[i] = tokens[i].lower()
     
    comment_words += " ".join(tokens)+" "
 
wordcloud = WordCloud(width = 800, height = 800,
                background_color ='white',
                stopwords = stopwords,
                min_font_size = 10).generate(comment_words)
"""
# plot the WordCloud image    
#cv2.imwrite('wordcloud.jpg', wordcloud)                  
#plt.figure(figsize = (8, 8), facecolor = None)
#plt.imshow(wordcloud)
#plt.axis("off")
#plt.tight_layout(pad = 0)
 
#plt.show()
#wordcloudImg("Sentiment/Tweets/1006-processed.csv")