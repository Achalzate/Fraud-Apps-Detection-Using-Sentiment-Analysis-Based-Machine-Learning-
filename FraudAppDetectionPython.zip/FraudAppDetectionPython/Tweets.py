import tweepy
import csv #Import csv
import string
def remove_non_ascii(a_str):
    ascii_chars = set(string.printable)

    return ''.join(
        filter(lambda x: x in ascii_chars, a_str)
    )
def save_tweet_to_csv(lst, csv_file):   
    tweet_txt=""
    with open(csv_file, 'w') as csv:
        csv.write('id,tweet\n')
        for i in range(len(lst)) : 
            tweet_txt=remove_non_ascii(str(lst[i][1]))   
            tweet_txt = tweet_txt.encode("ascii", "ignore")
            tweet_txt = tweet_txt.decode()            
            tweet_txt=tweet_txt.replace(',',' ')
            csv.write(str(lst[i][0])+","+tweet_txt)         
            csv.write('\n')
def getTweets(csvpath="NA",title="NA"):
    auth = tweepy.auth.OAuthHandler('u00RnlN6ZUofOFTgAayzui1AR', 'bGy7iaiDVCJl934k1bcCInDAOxPjkkITosUn3d48UGQAsDfvvd')
    #auth = tweepy.auth.OAuthHandler('FFfU939TpHmT3WYM3rWDFptfl', 'XyiIY4PlmhtTaNzrPDv2zcwdjuJBdVU8mHLZYm07IS0vlH6tQE')
    auth.set_access_token('1585141000581705729-NPsHehdqV8THr5UUGVm5mbP8f0tyhZ', 'lVYOPWhaxvAy15Qr78OuxU79XxmmnxHM1wbzNpJi0c5QJ')
    #auth.set_access_token('1660540984113938432-fuAUrCBRtATjGhgL1MzlhwxdTjNCnA', 'orReOfkAi5Y1jzDczwp54dxWeyYtJLZEuuRrjc5y5Lbys')

    api = tweepy.API(auth)

    # Open/create a file to append data to
    #csvFile = open(csvpath, 'a')

    #Use csv writer
    #csvWriter = csv.writer(csvFile)
    i=1
    lst1=[]
    for tweets in api.search_tweets(q=title,count=100, lang="en"):
        #print(tweets.text)
        lst1.append([str(i),tweets.text.encode('utf-8')])
        i=i+1
    save_tweet_to_csv(lst1,csvpath)
        #print("==================================")
        
    #print("cnt="+str(i))
    """
    for tweet in tweepy.Cursor(api.search_tweets,
                            q = "covid", 
                            until = "2023-02-15",
                            lang = "en").items():

        # Write a row to the CSV file. I use encode UTF-8
        print(tweet.text)
        csvWriter.writerow([tweet.created_at, tweet.text.encode('utf-8')])
        print(tweet.created_at, tweet.text)
    csvFile.close()
    """


     