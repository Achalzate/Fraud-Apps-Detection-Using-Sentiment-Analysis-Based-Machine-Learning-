package com.fraud.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FraudAppDetectionApplication {

	public static void main(String[] args) {
		SpringApplication.run(FraudAppDetectionApplication.class, args);
	}

}
